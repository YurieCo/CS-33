


int bitAnd(int, int);
int test_bitAnd(int, int);
int bitMask(int, int);
int test_bitMask(int, int);
int bitParity(int);
int test_bitParity(int);
int bitXor(int, int);
int test_bitXor(int, int);
int conditional(int, int, int);
int test_conditional(int, int, int);
int copyLSB(int);
int test_copyLSB(int);
int evenBits();
int test_evenBits();
int getByte(int, int);
int test_getByte(int, int);
int isLess(int, int);
int test_isLess(int, int);
int isNonZero(int);
int test_isNonZero(int);
int isPower2(int);
int test_isPower2(int);
int isZero(int);
int test_isZero(int);
int logicalNeg(int);
int test_logicalNeg(int);
int multFiveEights(int);
int test_multFiveEights(int);
int negate(int);
int test_negate(int);
